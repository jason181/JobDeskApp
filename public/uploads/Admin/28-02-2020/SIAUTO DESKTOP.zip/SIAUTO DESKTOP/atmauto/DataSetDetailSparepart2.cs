﻿namespace atmauto
{


    partial class DataSetDetailSparepart2
    {
        partial class detail_spareparts_2DataTable
        {
        }
    }
}
