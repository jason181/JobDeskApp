﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace atmauto.Entity
{
    class Role
    {
        public string Id_Role;
        public string Nama_Role;
        
        public string id_role { get; set; }
        public string nama_role { get; set; }
    }
}
