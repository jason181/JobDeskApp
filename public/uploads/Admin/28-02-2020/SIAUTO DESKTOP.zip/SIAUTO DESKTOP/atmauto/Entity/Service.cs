﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace atmauto.Entity
{
    class Service
    {
        public string Id_Jasa;
        public string Nama_Jasa;
        public double Harga_Jasa;

        public string id_Jasa { get; set; }
        public string nama_Jasa { get; set; }
        public string harga_Jasa { get; set; }
        
    }
}
