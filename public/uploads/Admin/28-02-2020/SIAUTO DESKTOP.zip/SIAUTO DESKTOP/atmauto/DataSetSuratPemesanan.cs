﻿namespace atmauto
{


    partial class DataSetSuratPemesanan
    {
        partial class surat_pemesananDataTable
        {
        }
    }
}
