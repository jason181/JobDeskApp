﻿namespace atmauto
{


    partial class DataSetPengeluaranBulanan
    {
        partial class pengeluaran_bulananDataTable
        {
        }
    }
}
