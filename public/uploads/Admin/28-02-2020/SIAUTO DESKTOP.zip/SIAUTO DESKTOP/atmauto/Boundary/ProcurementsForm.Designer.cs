﻿namespace atmauto.Boundary
{
    partial class ProcurementsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ProcurementsForm));
            this.menuPanel = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.dataGridViewProcurements = new System.Windows.Forms.DataGridView();
            this.Aksi = new System.Windows.Forms.DataGridViewButtonColumn();
            this.label11 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label12 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.buttonProcurements = new System.Windows.Forms.Button();
            this.buttonLogOut = new System.Windows.Forms.Button();
            this.buttonSparepart = new System.Windows.Forms.Button();
            this.buttonReport = new System.Windows.Forms.Button();
            this.slidePanel = new System.Windows.Forms.Panel();
            this.cabangButton = new System.Windows.Forms.Button();
            this.serviceButton = new System.Windows.Forms.Button();
            this.pegawaiButton = new System.Windows.Forms.Button();
            this.homeButton = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.searchButton = new System.Windows.Forms.Button();
            this.menuPanel.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewProcurements)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuPanel
            // 
            this.menuPanel.BackColor = System.Drawing.SystemColors.Control;
            this.menuPanel.Controls.Add(this.panel1);
            this.menuPanel.Controls.Add(this.panel2);
            this.menuPanel.Controls.Add(this.panel3);
            this.menuPanel.Controls.Add(this.panel4);
            this.menuPanel.Location = new System.Drawing.Point(0, 0);
            this.menuPanel.Name = "menuPanel";
            this.menuPanel.Size = new System.Drawing.Size(956, 539);
            this.menuPanel.TabIndex = 2;
            this.menuPanel.Paint += new System.Windows.Forms.PaintEventHandler(this.menuPanel_Paint);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.button6);
            this.panel1.Controls.Add(this.button5);
            this.panel1.Controls.Add(this.searchButton);
            this.panel1.Controls.Add(this.dataGridViewProcurements);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Location = new System.Drawing.Point(205, 145);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(729, 382);
            this.panel1.TabIndex = 28;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // dataGridViewProcurements
            // 
            this.dataGridViewProcurements.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewProcurements.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Aksi});
            this.dataGridViewProcurements.Location = new System.Drawing.Point(3, 91);
            this.dataGridViewProcurements.MultiSelect = false;
            this.dataGridViewProcurements.Name = "dataGridViewProcurements";
            this.dataGridViewProcurements.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewProcurements.Size = new System.Drawing.Size(718, 288);
            this.dataGridViewProcurements.TabIndex = 147;
            this.dataGridViewProcurements.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewProcurements_CellContentClick);
            // 
            // Aksi
            // 
            this.Aksi.HeaderText = "Cetak";
            this.Aksi.Name = "Aksi";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Meiryo", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(204)))), ((int)(((byte)(255)))));
            this.label11.Location = new System.Drawing.Point(-9, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(283, 52);
            this.label11.TabIndex = 146;
            this.label11.Text = "Procurements";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(204)))), ((int)(((byte)(255)))));
            this.panel2.Controls.Add(this.label12);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(172, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(784, 21);
            this.panel2.TabIndex = 18;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Mongolian Baiti", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(353, 2);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(89, 16);
            this.label12.TabIndex = 170;
            this.label12.Text = "Admin Panel";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(204)))), ((int)(((byte)(255)))));
            this.panel3.Controls.Add(this.label9);
            this.panel3.Controls.Add(this.label10);
            this.panel3.Location = new System.Drawing.Point(200, 11);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(90, 117);
            this.panel3.TabIndex = 19;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Constantia", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(2, 95);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(85, 11);
            this.label9.TabIndex = 5;
            this.label9.Text = "Motorcycle Service";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Constantia", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(2, 80);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(73, 15);
            this.label10.TabIndex = 4;
            this.label10.Text = "Atma Auto";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(39)))), ((int)(((byte)(40)))));
            this.panel4.Controls.Add(this.buttonProcurements);
            this.panel4.Controls.Add(this.buttonLogOut);
            this.panel4.Controls.Add(this.buttonSparepart);
            this.panel4.Controls.Add(this.buttonReport);
            this.panel4.Controls.Add(this.slidePanel);
            this.panel4.Controls.Add(this.cabangButton);
            this.panel4.Controls.Add(this.serviceButton);
            this.panel4.Controls.Add(this.pegawaiButton);
            this.panel4.Controls.Add(this.homeButton);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(39)))), ((int)(((byte)(40)))));
            this.panel4.Location = new System.Drawing.Point(0, 0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(172, 539);
            this.panel4.TabIndex = 17;
            // 
            // buttonProcurements
            // 
            this.buttonProcurements.FlatAppearance.BorderSize = 0;
            this.buttonProcurements.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonProcurements.Font = new System.Drawing.Font("Century", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonProcurements.ForeColor = System.Drawing.Color.White;
            this.buttonProcurements.Image = ((System.Drawing.Image)(resources.GetObject("buttonProcurements.Image")));
            this.buttonProcurements.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.buttonProcurements.Location = new System.Drawing.Point(11, 341);
            this.buttonProcurements.Name = "buttonProcurements";
            this.buttonProcurements.Size = new System.Drawing.Size(160, 49);
            this.buttonProcurements.TabIndex = 16;
            this.buttonProcurements.Text = "   Procurements";
            this.buttonProcurements.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.buttonProcurements.UseVisualStyleBackColor = true;
            // 
            // buttonLogOut
            // 
            this.buttonLogOut.FlatAppearance.BorderSize = 0;
            this.buttonLogOut.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonLogOut.Font = new System.Drawing.Font("Century", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonLogOut.ForeColor = System.Drawing.Color.White;
            this.buttonLogOut.Image = ((System.Drawing.Image)(resources.GetObject("buttonLogOut.Image")));
            this.buttonLogOut.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.buttonLogOut.Location = new System.Drawing.Point(10, 450);
            this.buttonLogOut.Name = "buttonLogOut";
            this.buttonLogOut.Size = new System.Drawing.Size(160, 49);
            this.buttonLogOut.TabIndex = 7;
            this.buttonLogOut.Text = "        Log Out";
            this.buttonLogOut.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.buttonLogOut.UseVisualStyleBackColor = true;
            this.buttonLogOut.Click += new System.EventHandler(this.buttonLogOut_Click);
            // 
            // buttonSparepart
            // 
            this.buttonSparepart.FlatAppearance.BorderSize = 0;
            this.buttonSparepart.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSparepart.Font = new System.Drawing.Font("Century", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonSparepart.ForeColor = System.Drawing.Color.White;
            this.buttonSparepart.Image = ((System.Drawing.Image)(resources.GetObject("buttonSparepart.Image")));
            this.buttonSparepart.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.buttonSparepart.Location = new System.Drawing.Point(11, 175);
            this.buttonSparepart.Name = "buttonSparepart";
            this.buttonSparepart.Size = new System.Drawing.Size(160, 49);
            this.buttonSparepart.TabIndex = 15;
            this.buttonSparepart.Text = "                         Sparepart";
            this.buttonSparepart.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.buttonSparepart.UseVisualStyleBackColor = true;
            this.buttonSparepart.Click += new System.EventHandler(this.buttonSparepart_Click);
            // 
            // buttonReport
            // 
            this.buttonReport.FlatAppearance.BorderSize = 0;
            this.buttonReport.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonReport.Font = new System.Drawing.Font("Century", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonReport.ForeColor = System.Drawing.Color.White;
            this.buttonReport.Image = ((System.Drawing.Image)(resources.GetObject("buttonReport.Image")));
            this.buttonReport.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.buttonReport.Location = new System.Drawing.Point(12, 394);
            this.buttonReport.Name = "buttonReport";
            this.buttonReport.Size = new System.Drawing.Size(160, 49);
            this.buttonReport.TabIndex = 6;
            this.buttonReport.Text = "        Report";
            this.buttonReport.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.buttonReport.UseVisualStyleBackColor = true;
            this.buttonReport.Click += new System.EventHandler(this.buttonReport_Click);
            // 
            // slidePanel
            // 
            this.slidePanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(204)))), ((int)(((byte)(255)))));
            this.slidePanel.Location = new System.Drawing.Point(1, 340);
            this.slidePanel.Name = "slidePanel";
            this.slidePanel.Size = new System.Drawing.Size(10, 49);
            this.slidePanel.TabIndex = 5;
            // 
            // cabangButton
            // 
            this.cabangButton.FlatAppearance.BorderSize = 0;
            this.cabangButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cabangButton.Font = new System.Drawing.Font("Century", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cabangButton.ForeColor = System.Drawing.Color.White;
            this.cabangButton.Image = ((System.Drawing.Image)(resources.GetObject("cabangButton.Image")));
            this.cabangButton.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.cabangButton.Location = new System.Drawing.Point(12, 288);
            this.cabangButton.Name = "cabangButton";
            this.cabangButton.Size = new System.Drawing.Size(160, 49);
            this.cabangButton.TabIndex = 3;
            this.cabangButton.Text = "        Branch";
            this.cabangButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.cabangButton.UseVisualStyleBackColor = true;
            this.cabangButton.Click += new System.EventHandler(this.cabangButton_Click);
            // 
            // serviceButton
            // 
            this.serviceButton.FlatAppearance.BorderSize = 0;
            this.serviceButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.serviceButton.Font = new System.Drawing.Font("Century", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.serviceButton.ForeColor = System.Drawing.Color.White;
            this.serviceButton.Image = ((System.Drawing.Image)(resources.GetObject("serviceButton.Image")));
            this.serviceButton.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.serviceButton.Location = new System.Drawing.Point(12, 233);
            this.serviceButton.Name = "serviceButton";
            this.serviceButton.Size = new System.Drawing.Size(160, 49);
            this.serviceButton.TabIndex = 2;
            this.serviceButton.Text = "        Service";
            this.serviceButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.serviceButton.UseVisualStyleBackColor = true;
            this.serviceButton.Click += new System.EventHandler(this.serviceButton_Click);
            // 
            // pegawaiButton
            // 
            this.pegawaiButton.FlatAppearance.BorderSize = 0;
            this.pegawaiButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.pegawaiButton.Font = new System.Drawing.Font("Century", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pegawaiButton.ForeColor = System.Drawing.Color.White;
            this.pegawaiButton.Image = ((System.Drawing.Image)(resources.GetObject("pegawaiButton.Image")));
            this.pegawaiButton.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.pegawaiButton.Location = new System.Drawing.Point(12, 123);
            this.pegawaiButton.Name = "pegawaiButton";
            this.pegawaiButton.Size = new System.Drawing.Size(160, 49);
            this.pegawaiButton.TabIndex = 1;
            this.pegawaiButton.Text = "        Employees";
            this.pegawaiButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.pegawaiButton.UseVisualStyleBackColor = true;
            this.pegawaiButton.Click += new System.EventHandler(this.pegawaiButton_Click);
            // 
            // homeButton
            // 
            this.homeButton.FlatAppearance.BorderSize = 0;
            this.homeButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.homeButton.Font = new System.Drawing.Font("Century", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.homeButton.ForeColor = System.Drawing.Color.White;
            this.homeButton.Image = ((System.Drawing.Image)(resources.GetObject("homeButton.Image")));
            this.homeButton.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.homeButton.Location = new System.Drawing.Point(12, 68);
            this.homeButton.Name = "homeButton";
            this.homeButton.Size = new System.Drawing.Size(160, 49);
            this.homeButton.TabIndex = 0;
            this.homeButton.Text = "        Home";
            this.homeButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.homeButton.UseVisualStyleBackColor = true;
            this.homeButton.Click += new System.EventHandler(this.homeButton_Click);
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.ForeColor = System.Drawing.Color.Transparent;
            this.button6.Location = new System.Drawing.Point(184, 55);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(85, 31);
            this.button6.TabIndex = 171;
            this.button6.Text = "Finished";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.DarkOrange;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.ForeColor = System.Drawing.Color.Transparent;
            this.button5.Location = new System.Drawing.Point(93, 55);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(85, 31);
            this.button5.TabIndex = 170;
            this.button5.Text = "Printed";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // searchButton
            // 
            this.searchButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(153)))), ((int)(((byte)(230)))));
            this.searchButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.searchButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.searchButton.ForeColor = System.Drawing.Color.Transparent;
            this.searchButton.Location = new System.Drawing.Point(2, 55);
            this.searchButton.Name = "searchButton";
            this.searchButton.Size = new System.Drawing.Size(85, 31);
            this.searchButton.TabIndex = 169;
            this.searchButton.Text = "Ordered";
            this.searchButton.UseVisualStyleBackColor = false;
            this.searchButton.Click += new System.EventHandler(this.searchButton_Click);
            // 
            // ProcurementsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(956, 539);
            this.Controls.Add(this.menuPanel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "ProcurementsForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ProcurementsForm";
            this.Load += new System.EventHandler(this.ProcurementsForm_Load);
            this.menuPanel.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewProcurements)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel menuPanel;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button buttonProcurements;
        private System.Windows.Forms.Button buttonLogOut;
        private System.Windows.Forms.Button buttonSparepart;
        private System.Windows.Forms.Button buttonReport;
        private System.Windows.Forms.Panel slidePanel;
        private System.Windows.Forms.Button cabangButton;
        private System.Windows.Forms.Button serviceButton;
        private System.Windows.Forms.Button pegawaiButton;
        private System.Windows.Forms.Button homeButton;
        private System.Windows.Forms.DataGridView dataGridViewProcurements;
        private System.Windows.Forms.DataGridViewButtonColumn Aksi;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button searchButton;
    }
}