﻿namespace atmauto
{


    partial class SuratPerintahKerja
    {
        partial class pegawai_on_duties_2DataTable
        {
        }

        partial class detail_jasasDataTable
        {
        }

        partial class konsumensDataTable
        {
        }
    }
}
