﻿namespace atmauto
{


    partial class DataSetPendapatanTahun
    {
        partial class pendapatan_tahunanDataTable
        {
        }
    }
}
