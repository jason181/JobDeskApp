﻿namespace atmauto
{


    partial class DataSetPenjualanJasa
    {
        partial class penjualan_jasaDataTable
        {
        }
    }
}
