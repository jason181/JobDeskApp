﻿namespace atmauto
{


    partial class DataSetSisaStok
    {
    }
}
