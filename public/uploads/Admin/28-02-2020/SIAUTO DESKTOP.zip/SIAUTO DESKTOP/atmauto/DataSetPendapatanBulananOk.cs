﻿namespace atmauto
{


    partial class DataSetPendapatanBulananOk
    {
        partial class pendapatan_bulananDataTable
        {
        }

        partial class DataTable1DataTable
        {
        }

        partial class tahunDataTable
        {
        }
    }
}
