// import Vue from 'vue'
// import VueRouter from 'vue-router'

// Vue.use(VueRouter)

// const HomeLayout = Vue.component('HomeLayout',require('./components/layout/homelayout.vue'));
// const Register = Vue.component('Register', require('./components/home/register.vue'));
// const LogIn = Vue.component('LogIn', require('./components/home/login.vue'));

// const routes = [
//     {
//         routes:[
//             {
//                 name: 'HomeLayout',
//                 path: '/',
//                 component: HomeLayout
//             },
//             {
//                 name: 'Register',
//                 path: '/register',
//                 component: Register
//             },
//             {
//                 name: 'LogIn',
//                 path: '/login',
//                 component: LogIn
//             }
//         ]
//       }
// ]

// const router = new VueRouter({routes: routes});
// export default router
