<template>
    <!-- SHOP -->
        <div class="container">
            <br>
            <h1 class="title is-2" style="color:rgb(18, 185, 18)">Hair Treatment</h1>
            <div class="columns is-mobile">
            <div class="column">
                <div class="box">
                    <p style="text-align:center"><strong>Moremo</strong></p>
                    <figure class="image is-256x256">
                        <img src="../img/hairTreatment/5.jpg">
                        <p style="text-align:center"><strong>Rp. 150.000</strong></p>
                    </figure>
                    <button class="button buy">Buy</button>
                </div>
            </div>

            <div class="column">
                <div class="box">
                    <p style="text-align:center"><strong>Exo Brazilian</strong></p>
                    <figure class="image is-256x256">
                        <img src="../img/hairTreatment/6.jpg">
                        <p style="text-align:center"><strong>Rp. 90.000</strong></p>
                    </figure>
                 <button class="button buy">Buy</button>
                </div>
            </div>

            <div class="column">
                <div class="box">
                    <p style="text-align:center"><strong>Inoar Argan Oil</strong></p>
                    <figure class="image is-256x256">
                        <img src="../img/hairTreatment/3.jpeg">
                        <p style="text-align:center"><strong>Rp. 200.000</strong></p>
                    </figure>
                    <button class="button buy">Buy</button>
                </div>
            </div>

            <div class="column">
                <div class="box">
                    <p style="text-align:center"><strong>Kerastase Paris</strong></p>
                    <figure class="image is-256x256">
                        <img src="../img/hairTreatment/4.png">
                        <p style="text-align:center"><strong>Rp. 70.000</strong></p>
                    </figure>
                    <button class="button buy">Buy</button>
                </div>
            </div>
        </div>
    </div>    
</template>

<style>
.buy{
    background: rgb(18, 185, 18);
    color: white;
    width: 100px;
    font-size: 20px;
    margin-left: 85px;
}
</style>
