<template>
<!-- <div class="container is-fullhd"> -->
    <div class="notification style">
        <div class="columns">
            <div class="column">
                <h1 class="title is-2" style="color:rgb(0, 140, 255)">Contact</h1>
                <h1 class="title is-4" style="color:black">Email: bequeen@thekingcorp.org</h1>
                <h1 class="title is-4" style="color:black">Address : Jl. The King Number 4545, Yogyakarta</h1>
                <h1 class="title is-4" style="color:black">Phone : (0751) 561290</h1>
            </div>
            <div class="column">
                <img src="../img/services.jpg">
            </div>
        </div>
    </div>
<!-- </div> -->
</template>

<style>
.contact{
    background: #cce6ff;
}
</style>