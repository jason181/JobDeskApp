<template>
    <!-- SHOP -->
        <div class="container">
            <br>
            <h1 class="title is-2" style="color:rgb(0, 140, 255)">Body Treatment</h1>
            <div class="columns is-mobile">
            <div class="column">
                <div class="box">
                    <p style="text-align:center" ><strong>Purbasari</strong></p>
                    <figure class="image is-256x256">
                        <img src="../img/body/7.png">
                        <p style="text-align:center"><strong>Rp. 95.000</strong></p>
                    </figure>
                    <button class="button buyB">Buy</button>
                </div>
            </div>

            <div class="column">
                <div class="box">
                    <p style="text-align:center"><strong>Votary</strong></p>
                    <figure class="image is-256x256">
                        <img src="../img/body/8.jpg">
                        <p style="text-align:center"><strong>Rp. 70.000</strong></p>
                    </figure>
                    <button class="button buyB">Buy</button>
                </div>
            </div>

            <div class="column">
                <div class="box">
                    <p style="text-align:center"><strong>Mustika Ratu</strong></p>
                    <figure class="image is-256x256">
                        <img src="../img/body/9.jpg">
                        <p style="text-align:center"><strong>Rp. 80.000</strong></p>
                    </figure>
                    <button class="button buyB">Buy</button>
                </div>
            </div>

            <div class="column">
                <div class="box">
                    <p style="text-align:center"><strong>Thai's Body Scrub</strong></p>
                    <figure class="image is-256x256">
                        <img src="../img/body/10.jpg">
                        <p style="text-align:center"><strong>Rp. 110.000</strong></p>
                    </figure>
                    <button class="button buyB">Buy</button>
                </div>
            </div>
        </div>
    </div>    
</template>

<script>
export default{
    
}
</script>

<style>
.buyB{
    background: rgb(0, 140, 255);
    color: white;
    width: 100px;
    font-size: 20px;
    margin-left: 85px;
}
</style>
